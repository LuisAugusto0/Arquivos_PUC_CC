class principal{
	public static void main(String[] args){
		Retangulo quadra = new Retangulo();
		MyIO.print("O valor do perímetro da quadra é " + quadra.getPerimetro() + ". O valor da área é " + quadra.getPerimetro());
	}
}
