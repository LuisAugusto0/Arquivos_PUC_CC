Envio da guia 10 e da atividade de recuperação refeita.

Para a guia 10 não entendi muito bem principalmente a implementação do autômato de pilha, então não tenho certeza se está correto ou não. 
Se puder colocar oque deveria ser alterado eu agradeço.